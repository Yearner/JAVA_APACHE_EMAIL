See the [JavaMail web site](https://javaee.github.io/javamail).
